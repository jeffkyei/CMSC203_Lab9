package jkyeiasare1;

public class CheckingAccount extends BankAccount{
	final static int FEE = 15;
	public CheckingAccount(String owner, double amount ) {
		super(owner, amount);
		setAccountNumber(getAccountNumber() + "-10");
	}
	public boolean withdraw(double amount) {
		boolean val = true;
		amount = amount + FEE;
		return super.withdraw(amount);
	}
}
