package jkyeiasare1;

public class SavingsAccount extends BankAccount {
	double rate = 0.025;
	int savingsNumber = 0;
	static String accountNumber;
	public SavingsAccount(String owner, double balance) {
		super(owner, balance);
		accountNumber = BankAccount.getAccountNumber() + " " + savingsNumber;
		
	}
	public SavingsAccount(SavingsAccount s, double balance) {
		super(s, balance);
		savingsNumber = s.savingsNumber + 1;
		accountNumber = BankAccount.getAccountNumber() + "-" + savingsNumber;
	}
	public void postInterest() {
		setBalance(getBalance() * (rate/12));
	}
	
	
	public static String getAccountNumber(){
		return accountNumber;
	}
	
}
